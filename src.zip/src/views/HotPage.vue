<template>
  <div class="page">
    <Hot></Hot>
  </div>
</template>

<script>
import Hot from '@/components/Hot'
export default {
  data () {
    return {
    }
  },

  components: {
    Hot
  },

  methods: {}
}
</script>

<style scoped>
</style>