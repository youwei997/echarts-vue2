<template>
  <div class="page">
    <Map></Map>
  </div>
</template>

<script>
import Map from '@/components/Map'
export default {
  data () {
    return {
    }
  },

  components: {
    Map
  },

  methods: {}
}
</script>

<style scoped>
</style>