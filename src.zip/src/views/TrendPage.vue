<template>
  <div class="page">
    <Trend></Trend>
  </div>
</template>

<script>
import Trend from '@/components/Trend'
export default {
  data () {
    return {
    }
  },

  components: {
      Trend
  },

  methods: {}
}
</script>

<style scoped>
</style>