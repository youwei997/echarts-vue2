/* 针对/sellerpage这条路径而显示的 */
<template>
  <div class="page">
    <Stock></Stock>
  </div>
</template>

<script>
import Stock from "@/components/Stock";
export default {
  components: {
    Stock,
  },
};
</script>

<style></style>
