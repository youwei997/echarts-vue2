/* 针对/sellerpage这条路径而显示的 */
<template>
  <div class="page">
    <Seller></Seller>
  </div>
</template>

<script>
import Seller from "@/components/Seller";
export default {
  components: {
    Seller,
  },
};
</script>

<style></style>
