<template>
  <div class="page">
    <Rank></Rank>
  </div>
</template>

<script>
import Rank from '@/components/Rank'
export default {
  data () {
    return {
    }
  },

  components: {
    Rank
  },

  methods: {}
}
</script>

<style scoped>
</style>